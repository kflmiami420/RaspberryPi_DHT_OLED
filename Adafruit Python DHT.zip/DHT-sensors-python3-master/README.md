DHT-sensors-python3
===================

Versione del software di Tony DiCola per Adafruit adattato a Python 3
Questo progetto deriva dal progetto di Tony DiCola che pur funzionando sia su Raspberry che Beaglebone si limita alla versione 2.x di python 
